import { config } from "dotenv";
import express from "express";
import cors from "cors";
import cookieparser from "cookie-parser";
import fileupload from "express-fileupload";
import dbconnection from "./database/dbconnection.js";
import messagerouter from "./router/messagerouter.js"


const app = express();
config({path: "./config/config.env"});

app.use(cors({
    origin: [process.env.FRONTEND_URI,process.env.DESHBORD_URI],
   methods:["GET","POST","PUT","DELETE"],
   creadentials:true,
}));

 app.use(cookieparser());
 app.use(express.json());
 app.use(express.urlencoded({extended:true}));

 app.use(fileupload({
    usetempfile:true,
    tempfileDir:"/tmp"
 }));

 app.use("/api/v1/message",messagerouter)
 dbconnection()
export default app;